<?php
//declaration des variables
$id= isset($_POST["id"])? $_POST["id"] : "";
$prenom= isset($_POST["prenom"])? $_POST["prenom"] : "";
$nom = isset($_POST["nom"])? $_POST["nom"] : "";
$dateAdhesion = isset($_POST["dateAdhesion"])? $_POST["dateAdhesion"] : "";
$position = isset($_POST["position"])? $_POST["position"] : "";
$majeure = isset($_POST["majeure"])? $_POST["majeure"] : "";
$moyenneCumulative = isset($_POST["moyenneCumulative"])? $_POST["moyenneCumulative"] : "";
$paysetudeInterl = isset($_POST["paysetudeInterl"])? $_POST["paysetudeInterl"] : "";
$erreur = "";
if($id==""){
    $erreur .="Le champ Id est vide. <br>";
}
if ($prenom == "") {
$erreur .= "Le champ Prenom est vide. <br>";
}
if ($nom == "") {
$erreur .= "Le champ Nom est vide. <br>";
}
if ($dateAdhesion == "") {
$erreur .= "Le champ dateAdhesion est vide est vide. <br>";
}
if ($position == "") {
$erreur .= "Le champ Position est vide. <br>";
}
if ($majeure == "") {
    $erreur .= "Le champ Majeure est vide. <br>";
}
if ($moyenneCumulative == "") {
    $erreur .= "Le champ Moyenne Cumulative est vide. <br>";
}
if ($paysetudeInterl == "") {
    $erreur .= "Le champ Pays Etude Interl est vide. <br>";
    }    
    
if ($erreur == "") {
echo "Formulaire valide.";

echo "<br>Id :".$id;
echo "<br>Prenom : " .$prenom;
echo "<br>Nom :".$nom;
echo "<br>Date d'Adhésion :".$dateAdhesion;
echo "<br>Position".$position;
echo "<br>Majeure :".$majeure;
echo "<br>Moyenne Cumulative :".$moyenneCumulative;
echo "<br>Pays Etude Interl :".$paysetudeInterl;

} else {
echo "Erreur: <br>" . $erreur;
}
?>
