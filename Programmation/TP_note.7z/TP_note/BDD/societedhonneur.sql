-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Dim 08 Avril 2018 à 20:30
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `tpnote2_2018`
--

-- --------------------------------------------------------

--
-- Structure de la table `societedhonneur`
--

CREATE TABLE `societedhonneur` (
  `ID` int(11) NOT NULL,
  `Prenom` varchar(255) NOT NULL,
  `Nom` varchar(255) NOT NULL,
  `DateAdhesion` date NOT NULL,
  `Poste` varchar(255) NOT NULL,
  `Majeure` varchar(255) NOT NULL,
  `MoyenneCummulative` float NOT NULL,
  `PaysEtudeInterl` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `societedhonneur`
--

INSERT INTO `societedhonneur` (`ID`, `Prenom`, `Nom`, `DateAdhesion`, `Poste`, `Majeure`, `MoyenneCummulative`, `PaysEtudeInterl`) VALUES
(100, 'Benjamin', 'Chapelle', '2015-07-01', 'AUDIT', 'Energie', 17.05, 'Espagne'),
(101, 'Francois', 'Macron', '2018-02-01', 'MEMBRE', 'Santé', 16.25, 'USA'),
(102, 'Eva', 'Munoz', '2017-01-15', 'MEMBRE', 'Energie', 15.51, 'Canada'),
(103, 'Lynda', 'Anderson', '2015-06-01', 'MEMBRE', 'Information', 18.12, 'Japon'),
(104, 'Roger', 'Schultz', '2015-05-01', 'VP_EVENT', 'ObjetsCon', 17.98, 'Corée du Sud'),
(105, 'Sylvain', 'Patten', '2016-04-15', 'PRES', 'Embarqué', 15.55, 'USA'),
(106, 'Malo', 'Griffith', '2014-01-05', 'SEC', 'Embarqué', 18.75, 'Canada'),
(107, 'Tanguy', 'Bonnevie', '2014-05-01', 'VP_FINANCE', 'Transports', 17.75, 'Angleterre'),
(108, 'Fatima', 'Al Haddad', '2013-05-15', 'MEMBRE', 'Information', 16.25, 'Allemagne'),
(109, 'Wilfred', 'Nguyen', '2016-11-01', 'MEMBRE', 'Santé', 17.25, 'Japon');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `societedhonneur`
--
ALTER TABLE `societedhonneur`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `societedhonneur`
--
ALTER TABLE `societedhonneur`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
