<?php

//connecter l'utilisateur dans BDD
$db_handle = mysqli_connect('localhost','root','');
$db_found = mysqli_select_db($db_handle,"societedhonneur");

//Si le BDD existe, faire le traitement
if($db_found){
    $sql = "SELECT*FROM membre";
    $result = mysqli_query($db_handle, $sql);

    while($data = mysqli_fetch_assoc($result)){
        echo "id: ".$data['id'].'<br>';
        echo "Prenom :".$data['Prenom'].'<br>';
        echo "Nom : ".$data['Nom'].'<br>';
        echo "DateAdhesion : ".$data['DateAdhesion'].'<br>';
        echo "Position : ".$data['Position'].'<br>';
        echo "Majeure : ".$data['Majeure'].'<br>';
        echo "MoyenneCummulative : ".$data['MoyenneCummulative'].'<br>';
        echo "PaysEtudeInterl : ".$data['PaysEtudeInterl'].'<br>';
    }//end while
}//end if
//Si la BDD n'existe pas
else{
    echo "Database not found";
}//end else

//fermer la connection
mysqli_close($db_handle);
?>