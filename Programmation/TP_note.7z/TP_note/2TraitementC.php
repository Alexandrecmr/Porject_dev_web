<?php
 
 $sql = SELECT Prenom, Nom, DateAdhesion, Poste, Majeure, MoyenneCummulative, PayesEtudeInterl FROM societedhonneur_tbl ORDER BY Majeure';
 // L'opérateur ORDER BY permet de classer soit alphabétiquement
 
?>