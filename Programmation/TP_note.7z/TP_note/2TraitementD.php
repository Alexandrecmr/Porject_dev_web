<?php
 
 $sql = SELECT Prenom, Nom, DateAdhesion, Poste, Majeure, MoyenneCummulative, PayesEtudeInterl FROM societedhonneur_tbl ORDER BY Majeure DESC;

 ?>